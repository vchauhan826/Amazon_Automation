package com.Amazon.ObjectRepo;

/**
 * 
 * @author virendra
 *
 */

public interface ObjectRepo {

	String SignInBtn = "ID####com.amazon.mShop.android.shopping:id/sign_in_button";
	String LoginTxt = "ID####ap_email_login";
	String ContinueBtn = "XPATH####(//*[contains(@resource-id,'continue')])[1]";
	
	String PasswordTxt = "ID####ap_password";
	String SignInSubmitBtn = "ID####signInSubmit";
	String SearchTxt = "ID####com.amazon.mShop.android.shopping:id/rs_search_src_text";
	
	String SelectedItemAuto = "XPATH####(//*[contains(@resource-id,'com.amazon.mShop.android.shopping:id/iss_search_dropdown_item_suggestions')])[1]";
	String SelectedItem = "XPATH####(//*[contains(@class,'android.view.View')])[1]";
	
	String AddToCartBtn = "ID####add-to-cart-button";
	String CartBox = "XPATH####//android.widget.ImageView[@content-desc='Cart']";
	String ProceedPayBtn = "XPATH####//android.widget.Button[@text='Proceed to Buy']";
	
	
	
	

}
