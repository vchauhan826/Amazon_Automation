package com.Amazon.Test;

import static org.testng.Assert.assertTrue;

import java.io.IOException;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

import org.testng.ITestResult;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.Amazon.genericLib.Drivers;
import com.Amazon.genericLib.ExcelLib;
import com.Amazon.ObjectRepo.ObjectRepo;
import com.Amazon.genericLib.Library;
import com.Amazon.genericLib.ReportLib;

import io.appium.java_client.MobileDriver;
import io.appium.java_client.TouchAction;
/**
 * 
 * @author virendra
 *
 */

public class amazonAutomation {
	/**
	 * launch amazon
	 * login to amazon
	 * search for 65 inch tv and select random tv
	 * add to card
	 * proceed with payment
	 */
    /** The logger. */
    public Logger logger = Logger.getLogger(amazonAutomation.class.getName());
	
	@BeforeClass
	 public void setUp() throws Exception {
		 logger.info("Load Test data");
		 ExcelLib.testDataLoad();
		 logger.info("Install and Launch Amazon Application");
		 Drivers.getDriver();
	}

	@Test
	public void LoginToAmazon() throws Exception{
		
		 logger.info("verify whether amazon app navigated to login screen or not");		 
		 assertTrue(Library.verifyIsDisplayed(ObjectRepo.SignInBtn), "not navigated to login screen");
		 logger.info("navigated to login screen");	
		 new ReportLib().takeScreenShot("LoginScreen");
		 
		 Library.click(ObjectRepo.SignInBtn);
		 Library.Wait_Till_ElementIsVisible(ObjectRepo.ContinueBtn);
		 logger.info("verify whether amazon app navigated to SignIn or not");		 
		 assertTrue(Library.verifyIsDisplayed(ObjectRepo.LoginTxt), "not navigated to SignIn screen");
		 logger.info("navigated to SignIn screen");
		 new ReportLib().takeScreenShot("SignInScreen");
		 
		 Library.enterText(ObjectRepo.LoginTxt, ExcelLib.wholeTestData.get("strUserName"));
		 Library.click(ObjectRepo.ContinueBtn);
		 Library.Wait_Till_ElementIsVisible(ObjectRepo.SignInSubmitBtn);
		 logger.info("verify whether amazon app navigated to Password or not");		 
		 assertTrue(Library.verifyIsDisplayed(ObjectRepo.PasswordTxt), "not navigated to Password screen");
		 logger.info("navigated to Password screen");
		 new ReportLib().takeScreenShot("PasswordScreen");
		 
		 Library.enterText(ObjectRepo.PasswordTxt, ExcelLib.wholeTestData.get("strPassword"));
		 Library.click(ObjectRepo.SignInSubmitBtn);
		 Library.Wait_Till_ElementIsVisible(ObjectRepo.SearchTxt);
		 logger.info("verify whether amazon app navigated to home screen or not");		 
		 assertTrue(Library.verifyIsDisplayed(ObjectRepo.SearchTxt), "not navigated to home screen");
		 logger.info("navigated to home screen");	
		 new ReportLib().takeScreenShot("HomeScreen");
	}
	
	@Test(dependsOnMethods={"LoginToAmazon"})
	public void searchForItem() throws Exception{
		logger.info("enter the item which want to search for");
		Library.enterText(ObjectRepo.SearchTxt, ExcelLib.wholeTestData.get("strSearchItem"));
		Library.Wait_Till_ElementIsVisible(ObjectRepo.SelectedItemAuto);
		Library.click(ObjectRepo.SelectedItemAuto);
		Library.Wait_Till_ElementIsVisible(ObjectRepo.SelectedItem);
		Library.click(ObjectRepo.SelectedItem);
		Library.Wait_Till_ElementIsVisible(ObjectRepo.AddToCartBtn);
		new ReportLib().takeScreenShot("ItemScreen");
		
		//Get and print current screen orientation.
		System.out.println("*--*--*-- Current screen orientation Is : " + Drivers.driver.getOrientation());
		System.out.println("*--*--*-- Changing screen Orientation to LANDSCAPE.");
		//Changing screen Orientation to LANDSCAPE.
		Drivers.driver.rotate(org.openqa.selenium.ScreenOrientation.LANDSCAPE);
		//Get and print screen orientation after changing It.
		System.out.println("*--*--*-- Now screen orientation Is : "+ Drivers.driver.getOrientation());
		//this ScrollToText() function is using appium inbuild function scrollTo()
	     // Scroll till element which contains "Add To Cart" text If It Is not visible on screen.
		new TouchAction((MobileDriver)Drivers.driver).press(277,847).moveTo(274, 651).release().perform();
		//Library.ScrollToText("Add To Cart");
		logger.info("verify whether Add To Cart is visible or not");		 
		assertTrue(Library.verifyIsDisplayed(ObjectRepo.AddToCartBtn), "Add To Cart not visible");
		logger.info("Add To Cart visible");
		new ReportLib().takeScreenShot("AddToCartScreen");
	}
	
	@Test(dependsOnMethods={"searchForItem"})
	public void AddToCartAndProceedPayment() throws Exception{
		System.out.println("*--*--*-- Changing screen Orientation to PORTRAIT.");
		//Changing screen Orientation to PORTRAIT.
		Drivers.driver.rotate(org.openqa.selenium.ScreenOrientation.PORTRAIT);
		//Get and print screen orientation after changing It.
		System.out.println("*--*--*-- Now screen orientation Is : "+ Drivers.driver.getOrientation());
		logger.info("click on add to cart button");
		Library.click(ObjectRepo.AddToCartBtn);
		Drivers.driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		Library.click(ObjectRepo.CartBox);
		Library.Wait_Till_ElementIsVisible(ObjectRepo.ProceedPayBtn);
		logger.info("verify whether navigated to payment screen or not");		 
		assertTrue(Library.verifyIsDisplayed(ObjectRepo.ProceedPayBtn), "not navigated to payment screen");
		logger.info("navigated to payment screen");
		new ReportLib().takeScreenShot("PaymentScreen");
	}
	
	@AfterMethod
	public void configAfterMtd(ITestResult t) throws IOException{
		boolean b = t.isSuccess();
		if(b){
			
		}else{
			String testName = t.getMethod().getMethodName();
			new ReportLib().takeScreenShot(testName);
		}
	}
		
    @AfterClass
	public void tearDown() {
	    Drivers.driver.quit();
    }	
		
}
