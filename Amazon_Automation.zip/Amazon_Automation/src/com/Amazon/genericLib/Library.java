package com.Amazon.genericLib;

import java.util.logging.Logger;

import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.appium.java_client.MobileElement;

/**
 * 
 * @author virendra
 *
 */

public class Library {

    /** The logger. */
    static Logger logger = Logger.getLogger(Library.class.getName());

    /**
     * Click.
     * @param objectName the object name
     * @throws Exception the exception
     */
    public static void click(String objectName) throws Exception {
        getElement(objectName).click();
    }

    /**
     * Enter text.
     * @param objectName the object name
     * @param text the text
     * @throws Exception the exception
     */
    public static void enterText(String objectName, String text) throws Exception {
        getElement(objectName).sendKeys(text);
    }
    
    public static String verifyText(String objectName) throws Exception {
            return getElement(objectName).getText();
        }
    
    public static void Wait_Till_ElementIsVisible(String objectName) throws Exception {
        WebDriverWait oWait;
        oWait = new WebDriverWait(Drivers.driver,20);
        oWait.until(ExpectedConditions.elementToBeClickable(getElement(objectName)));
  }
    
    public static boolean verifyIsDisplayed(String objectName) throws Exception {
    	try{
        return getElement(objectName).isDisplayed();
    	} catch (Exception e) {
            return false;
        }
    
    }

    /**
     * Gets the element.
     * @param objectName the object name
     * @return the element
     * @throws Exception the exception
     */
    public static MobileElement getElement(String objectName) throws Exception {
        
        if(objectName.contains("XPATH####")){
            try {
                logger.info("Driver is trying to find the object using XPATH property");
                return (MobileElement) Drivers.driver.findElementByXPath(objectName.split("####")[1]);
            } catch (Exception e) {
            	throw new Exception("Object could not be found with XPATH property");
            }
        }
        
        if(objectName.contains("ID####")){
            try {
                logger.info("Driver is trying to find the object using ID property");
                return (MobileElement) Drivers.driver.findElementById(objectName.split("####")[1]);
            } catch (Exception e) {
            	throw new Exception("Object could not be found with ID property");
            }
        }

        if(objectName.contains("CSS####")){
            try {
                logger.info("Driver is trying to find the object using CSS property");
                return (MobileElement) Drivers.driver.findElementByCssSelector(objectName.split("####")[1]);
            } catch (Exception e) {
            	throw new Exception("Object could not be found with CSS property");
            }
        }
        
        if(objectName.contains("NAME####")){
            try {
                logger.info("Driver is trying to find the object using NAME property");
                return (MobileElement) Drivers.driver.findElementByName(objectName.split("####")[1]);
            } catch (Exception e) {
            	throw new Exception("Object could not be found with NAME property");
            }
        }

        if(objectName.contains("CLASS_NAME####")){
            try {
                logger.info("Driver is trying to find the object using CLASS_NAME property");
                return (MobileElement) Drivers.driver.findElementByClassName(objectName.split("####")[1]);
            } catch (Exception e) {
            	throw new Exception("Object could not be found with CLASS_NAME property");
            }
        }
        return null;
    }
    
	public static void ScrollToText(String strText) throws InterruptedException { 
		
		//Scroll till element which contains desired text. 
		Drivers.driver.scrollTo(strText);
	}
}