package com.Amazon.genericLib;

import java.io.File;

import org.openqa.selenium.remote.DesiredCapabilities;
import io.appium.java_client.remote.MobileCapabilityType;

/**
 * 
 * @author virendra
 *
 */

public class ConfigCapability{	
	
	public static  DesiredCapabilities capabilities;
		
	public static DesiredCapabilities configCapabilities() {
		
		 File classpathRoot = new File(System.getProperty("user.dir"));
		 File appDir = new File(classpathRoot, "/App/Amazon/");
		 File app = new File(appDir, "Amazon_shopping.apk");
		
		capabilities = new DesiredCapabilities();		
		capabilities.setCapability(MobileCapabilityType.PLATFORM_NAME,Constants.platformName);
		capabilities.setCapability(MobileCapabilityType.PLATFORM_VERSION,Constants.platformVersion);
		capabilities.setCapability(MobileCapabilityType.DEVICE_NAME,Constants.deviceName);
		capabilities.setCapability(MobileCapabilityType.APP, app.getAbsolutePath());
		capabilities.setCapability(MobileCapabilityType.APP_PACKAGE,Constants.appPackage);
		capabilities.setCapability(MobileCapabilityType.APP_ACTIVITY,Constants.appActivity);
		
		return capabilities;
	}
}
