package com.Amazon.genericLib;

import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;

import com.Amazon.genericLib.ConfigCapability;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.android.AndroidDriver;

/**
 * 
 * @author virendra
 *
 */

public class Drivers {
		
	@SuppressWarnings("rawtypes")
	public static AppiumDriver driver;
	public static  DesiredCapabilities capabilities;
			
    @SuppressWarnings("rawtypes")
	public static AppiumDriver getDriver() throws Exception{
            
    	    capabilities =ConfigCapability.configCapabilities();
			driver = new AndroidDriver(new URL(Constants.appiumServerUrl),capabilities);
			driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
			
			return driver;
	}
}