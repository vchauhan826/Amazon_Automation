package com.Amazon.genericLib;

import java.io.File;
import java.io.FileInputStream;
import java.util.HashMap;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelLib {
	
	public static HashMap<String, String> wholeTestData;
	@SuppressWarnings("resource")
	public static void testDataLoad() throws Exception {
		
	    try {
	    	File classpathRoot = new File(System.getProperty("user.dir"));
	    	File fileDir = new File(classpathRoot, "/ExcelData/");
	    	File fileDirWithName = new File(fileDir,Constants.strExcelFileName);
	    	FileInputStream fis = new FileInputStream(fileDirWithName);
	    	XSSFWorkbook workbook = new XSSFWorkbook(fis);
	    	XSSFSheet sheet = workbook.getSheet(Constants.strExcelSheetName);
	    	wholeTestData = new HashMap<String, String>();
			
			Row firstRow1 = sheet.getRow(0);
			int iColumnCount1 = firstRow1.getLastCellNum();	
			//System.out.println("last row : "+sheet.getLastRowNum());
			for (int i = 1; i <= sheet.getLastRowNum(); i++) {
				Row currentRow1 = sheet.getRow(i);
				//System.out.println("current row : "+i);
				for (int j = 0; j < iColumnCount1; j += 2) {
					wholeTestData.put(currentRow1.getCell(j).getStringCellValue(),
					      currentRow1.getCell(j+1).getStringCellValue());
				}
			}
			fis.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
}
	
}
	