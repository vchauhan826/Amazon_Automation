package com.Amazon.genericLib;

/**
 * 
 * @author virendra
 *
 */

public interface Constants {
	
	String appiumServerUrl = "http://127.0.0.1:4723/wd/hub";              /* all interface variable by default 
	                                                                    public final and static so no need to declare*/
	String platformName = "Android";
	String platformVersion= "9";
	String deviceName ="21931424";
	String appPackage ="com.amazon.mShop.android.shopping";
	String appActivity = "com.amazon.mShop.home.HomeActivity";
	
	String strExcelFileName = "TestData.xlsx";
	String strExcelSheetName = "TestData";

}
