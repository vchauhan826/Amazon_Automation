package com.Amazon.genericLib;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.support.events.EventFiringWebDriver;

/**
 * 
 * @author virendra
 *
 */

public class ReportLib{
	
	public void takeScreenShot(String fileName) throws IOException{
		
		File classpathRoot = new File(System.getProperty("user.dir"));
		File appDir = new File(classpathRoot, "/ScreenShot/");
		File srcImg = new EventFiringWebDriver(Drivers.driver).getScreenshotAs(OutputType.FILE);
		File dstFile = new File(appDir,fileName+".png");
		FileUtils.copyFile(srcImg, dstFile);
		
	}

}
